let users = [
  // {
  //     name: "test",
  //     email: "test@gmail.com",
  //     gender: "male",
  //     number: "0342",
  //     nationality: "Pakistan",
  //     passwords: "123",
  // }
];

const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();

app.use(cors());
app.use(morgan("dev"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

console.log(users);

app.post("/signup", function (req, res) {
  //logs
  console.log("body >>> ", req.body);
  //condition
  let alreadyExist = false;

  for (let i = 0; i < users.length; i++) {
    if (users[i].email === req.body.email) {
      alreadyExist = true;
      break;
    }
  }
  if (alreadyExist) {
    res.send("This email address already exist");
  } else {
    users.push(req.body);
    res.send("Sign Up Successfully");
  }
});

app.post("/login", function (req, res) {
  console.log("users >>>", users);
  console.log("currunt user data  >>", req.body);
  let userEmail = req.body.email;
  let userPassword = req.body.passwords;
  let isFound = false;

  for (let i = 0; i < users.length; i++) {
    if (users[i].email === userEmail) {
      isFound = i;
      var newEmail = userEmail;
      break;
    }
  }
  if (isFound === false) {
    res.send("Invalid email password");
  } else if (users[isFound].passwords === userPassword) {
    // res.send("signed in succesfully" )
    res.send(`signed in succesfully Name : ${users[isFound].name} Email : ${newEmail}
        Gender : ${users[isFound].gender} Nationality : ${users[isFound].nationality}
        Phone No : ${users[isFound].number}`);
  } else {
    res.status(403).send("wrong password or email");
  }
});
const PORT = process.env.PORT || 5000;
//server listening
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
